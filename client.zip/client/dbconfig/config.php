<?php
$connect=mysqli_connect ("127.0.0.1", "root", "") or die ('I cannot connect to the database because: ' . mysql_error());
mysqli_select_db ($connect,'weblove_attirerentals');
?>