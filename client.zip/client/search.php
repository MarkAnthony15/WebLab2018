<?php 
session_start();
    include('dbconfig/config.php');
?>
<!DOCTYPE html>
<html lang="en">

  <head>
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Costume And Attires</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/heroic-features.css" rel="stylesheet">

  </head>

  <body data-spy="scroll" data-target="#myScrollspy" data-offset="20" style="background-image: url(bg.jpg); background-size: contain; background-attachment: fixed;">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top text-white" id="myScrollspy" style="font-size: large; background-color: black;">
      <div class="container">
        <a class="navbar-brand text-info" style="font-size: larger; padding-top: 10px;" href="#home">Costumes and Attires</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
          	<form action="search.php" method="POST" class="md-form active-cyan-2 mb-3" style="padding-top: 10px;">
    	
				<input class="form-control" name="search" style="font-size: large;" type="text" placeholder="Search" aria-label="Search">
			</form>
			<div>
			
			<?php
			
			//$topic=$_REQUEST["topic"];
			$sql = $query = "SELECT product.name, product.rental_price, concat(serviceprovider.owner_firstname, ' ', serviceprovider.owner_lastname), product_category.category_name from product JOIN product_category on product.category_id = product_category.category_id JOIN serviceprovider on product.product_providerid = serviceprovider.serviceprov_id WHERE product.name LIKE '%casual%'";
			$result = mysqli_query($connect,$sql);
			$queryResults = mysqli_num_rows($result);	
			?>

			</div>
            <li class="nav-item">
              <a class="nav-link " href="#costumes">Costumes</a>
            </li>
            <li class="nav-item">
              <a class="nav-link " href="#attires">Attires</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="costumes.php">Rentals</a>
            </li>
            <li class="nav-item">
              <?php

              if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                  echo "<a class='nav-link' href='profile.php'>". $_SESSION['username'] ."</a>";
              } else {
                  echo "<a class='nav-link' href='index.php'>Login</a>";
              }
               ?>
            </li>
             
            <li class="nav-item">
              <?php
              if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                  echo "<a class='nav-link' href='logout.php'>Logout</a>";
              } else {
                  echo "";
              }
               ?>
            </li>
          </ul>
        </div>
      </div>
    </nav>

?>
<br>
<div>
	<?php
	if(isset($_POST['search'])){
		$search = mysqli_real_escape_string($connect,$_POST['search']);
		$sql = "SELECT product.name, product.rental_price, concat(serviceprovider.owner_firstname, ' ', serviceprovider.owner_lastname), product_category.category_name, product.product_image from product JOIN product_category on product.category_id = product_category.category_id JOIN serviceprovider on product.product_providerid = serviceprovider.serviceprov_id WHERE product.name LIKE '%$search%' OR product.rental_price LIKE '%$search%' OR serviceprovider.owner_firstname LIKE '%$search%' OR serviceprovider.owner_lastname LIKE '%$search%' OR product_category.category_name LIKE '%$search%' ";
		//$sql = "SELECT * FROM casual WHERE name LIKE '%$search%' OR price LIKE '%$search%' ";
		$result = mysqli_query($connect, $sql);
		$queryResult = mysqli_num_rows($result);

		if($queryResult > 0){
			while($row = mysqli_fetch_assoc($result)){
				?>
			<div class="col-md-4">
				<form method="post" action="costumes.php?action=add&id=<?php echo $row["id"]; ?>">
					<div class="panel">
					<div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">
						<img src="images/<?php echo $row["product_image"]; ?>" class="img-responsive" /><br />

						<h4 class="text-info"><?php echo $row["name"]; ?></h4>

						<h4 class="text-danger">$ <?php echo $row["rental_price"]; ?></h4>

						<input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />

						<input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />

					</div>
				</div>
				</form>
			</div>
			</div>
					<?php
			}

		}else{
			echo "There are no results matching your search!";
		}
	}


	?>
</div>

