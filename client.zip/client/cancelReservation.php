<?php
        session_start();
  		include('dbconfig/config.php');
      	$user = ($_SESSION['username']);
      				
      	$reservation_number= $_POST['reservation_number'];
      	$query = "select * from client where username ='".$_SESSION['username']."';";
        $result = mysqli_query($connect, $query);
        if(mysqli_num_rows($result) > 0)
        {
        while($row = mysqli_fetch_array($result))
        {
      	$updateQuery = "UPDATE transaction SET status = 'cancelled' where reservation_number = '".$reservation_number."';";
      	if ($connect->query($updateQuery) === TRUE) 
						{
						    header( "Location: profile.php");
						} 
						else 
						{
						    echo "Error updating record: " . $connect->error;
						}
		}
	}
	?>