<?php
        session_start();
  		include('dbconfig/config.php');
      	$user = ($_SESSION['username']);
      				
      	$old_password = $_POST['old_password'];
      	$new_password = $_POST['new_password'];
      	$confirm_password = $_POST['confirm_password'];

      	$query = "SELECT * from client where username ='".$user."';";

			$result = mysqli_query($connect, $query);

			if(mysqli_num_rows($result) > 0)
			{

			while($row = mysqli_fetch_array($result)) 
			{

				if ($old_password == $row['password']) 
				{
					if($new_password == $confirm_password)
					{

						$updateQuery = "UPDATE client SET password = '".$new_password."' where username ='".$user."';";

						if ($connect->query($updateQuery) === TRUE) 
						{
						    header( "Location: profile.php");
						} 
						else 
						{
						    echo "Error updating record: " . $connect->error;
						}
						
					} else {
						echo "Password does not match!";
					}
				} else {
					echo "old password incorrect";
				}
			}
			}
?>