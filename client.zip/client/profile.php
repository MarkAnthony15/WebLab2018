<?php 
session_start();
  	include('dbconfig/config.php');

if(isset($_POST["add_to_cart"]))
{
	if(isset($_SESSION["shopping_cart"]))
	{
		$item_array_product_code = array_column($_SESSION["shopping_cart"], "item_product_code");
		if(!in_array($_GET["product_code"], $item_array_product_code))
		{
			$count = count($_SESSION["shopping_cart"]);
			$item_array = array(
				'item_product_code'			=>	$_GET["product_code"],
				'item_name'			=>	$_POST["hidden_name"],
				'item_rental_price'		=>	$_POST["hidden_rental_price"],
				'item_quantity'		=>	$_POST["quantity"]
			);
			$_SESSION["shopping_cart"][$count] = $item_array;
		}
		else
		{
			echo '<script>alert("Item Already Added")</script>';
		}
	}
	else
	{
		$item_array = array(
			'item_product_code'			=>	$_GET["product_code"],
			'item_name'			=>	$_POST["hidden_name"],
			'item_rental_price'		=>	$_POST["hidden_rental_price"],
			'item_quantity'		=>	$_POST["quantity"]
		);
		$_SESSION["shopping_cart"][0] = $item_array;
	}
}

if(isset($_GET["action"]))
{
	if($_GET["action"] == "delete")
	{
		foreach($_SESSION["shopping_cart"] as $keys => $values)
		{
			if($values["item_product_code"] == $_GET["product_code"])
			{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>alert("Item Removed")</script>';
				echo '<script>window.location="costumes.php"</script>';
			}
		}
	}
}

?>


<!DOCTYPE html>
<html lang="en">
<style>
#customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 25px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:nth-child(odd){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #d9edf7;
    color: #31708f;
}
</style>

  <head>
    <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <link rel="stylesheet" href="style.css" >
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Costume And Attires</title>
     <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
        
    </style>
    <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/heroic-features.css" rel="stylesheet">

  </head>

  <body data-spy="scroll" data-target="#myScrollspy" data-offset="20" style="background-image: url(profile.jpg);">
    <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark fixed-top text-white" id="myScrollspy" style="font-size: large; background-color: black;">
      <div class="container">
        <a href="index.php"><img src="home design/img/logo.png" class="navbar-brand js-scroll-trigger" id="logo" style="width:90px;height:60px;"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
		<form action="search.php" method="POST" class="md-form active-cyan-2 mb-3" style="padding-top: 10px;">
    	
				<input class="form-control" name="search" style="font-size: large;" type="text" placeholder="Search" aria-label="Search">
			</form>
			<div>
			
			<?php
			
			//$topic=$_REQUEST["topic"];
			$sql = $query = "SELECT product.name, product.rental_price, concat(serviceprovider.owner_firstname, ' ', serviceprovider.owner_lastname), product_category.category_name from product JOIN product_category on product.category_id = product_category.category_id JOIN serviceprovider on product.product_providerid = serviceprovider.serviceprov_id WHERE product.name LIKE '%casual%'";
			$result = mysqli_query($connect,$sql);
			$queryResults = mysqli_num_rows($result);	
			?>

			</div>
          <ul class="navbar-nav ml-auto">
          	
            <li class="nav-item">
              <a class="nav-link" href="costumes.php">Rentals</a>
            </li>
            <li class="nav-item">
              <?php
              if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                  echo "<a class='nav-link' href='profile.php'>". $_SESSION['username'] ."</a>";
              } else {
                  echo "<a class='nav-link' href='index.php'>Login</a>";
              }
               ?>
            </li>
             
            <li class="nav-item">
              <?php
              if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                  echo "<a class='nav-link' href='logout.php'>Logout</a>";
              } else {
                  echo "";
              }
               ?>
            </li>
          </ul>
        </div>
      </div>
    </nav>
<div class="container" style="padding-top: 50px;">
  
        <div class="row">

            <div class="col-md-3">
                <ul class="nav nav-pills nav-stacked admin-menu" >
                    <li class="active"><a href="" data-target-id="profile" style="font-size: x-large; color: white;"><i class="glyphicon glyphicon-user"></i> Profile</a></li>
                    <li><a href="" data-target-id="change-password" style="font-size: x-large; color: white;"><i class="glyphicon glyphicon-lock"></i> Change Password</a></li>
                    <li><a href="" data-target-id="transaction" style="font-size: x-large; color: white;"><i class="glyphicon glyphicon-briefcase"></i> Transaction</a></li>
                </ul>
            </div>

            <div class="col-md-9  admin-content" id="profile" style="font-size: 150%">
                <div class="panel panel-info" style="margin: 1em;">
                    <div class="panel-heading">
                        <h3 class="panel-title">Name</h3>
                    </div>
                        <?php

                                $query = "SELECT * FROM client WHERE username ='".$_SESSION['username']."';";
                                $result = mysqli_query($connect, $query);
                                if(mysqli_num_rows($result) > 0)
                                {
                                  while($row = mysqli_fetch_array($result))
                                  {
                        ?>
                    <div class="panel-body" style="font-size: larger;">
                    <p>
                        <?php echo $row["firstname"]. " " .$row['lastname']; ?>
                    </p>
                    </div>
                </div>
                <div class="panel panel-info" style="margin: 1em;">
                    <div class="panel-heading">
                        <h3 class="panel-title">Username</h3>
                    </div>
                    <div class="panel-body" style="font-size: larger;">
                       <p><?php
                        echo $row['username']
                        ?></p>
                    </div>
                </div>
                 <div class="panel panel-info" style="margin: 1em;">
                    <div class="panel-heading">
                        <h3 class="panel-title">Email</h3>
                    </div>
                    <div class="panel-body" style="font-size: larger;">
                       <p><?php
                        echo $row['email']
                        ?></p>
                    </div>
                </div>
                 <div class="panel panel-info" style="margin: 1em;">
                    <div class="panel-heading">
                        <h3 class="panel-title" >Phone Number</h3>
                    </div>
                    <div class="panel-body" style="font-size: larger;">
                     <p><?php
                        echo $row['phone_number']
                        ?></p>
                    </div>
                </div>
                 <div class="panel panel-info" style="margin: 1em;">
                    <div class="panel-heading">
                        <h3 class="panel-title">Address</h3>
                    </div>
                    <div class="panel-body" style="font-size: larger;">
                     <p><?php
                        echo $row['address_line']
                        ?></p>
                    </div>
                  </div>
                     <div class="panel panel-info" style="margin: 1em;">
                    <div class="panel-heading">
                        <h3 class="panel-title">City</h3>
                    </div>
                    <div class="panel-body" style="font-size: larger;">
                       <p><?php
                        echo $row['city']
                        ?></p>
                    </div>
                  </div>
                     <div class="panel panel-info" style="margin: 1em;">
                    <div class="panel-heading">
                        <h3 class="panel-title">Province</h3>
                    </div>
                    <div class="panel-body" style="font-size: larger;">
                       <p><?php
                        echo $row['province']
                        ?></p>
                    </div>
                  </div>
                     <div class="panel panel-info" style="margin: 1em;">
                    <div class="panel-heading">
                        <h3 class="panel-title">Postal Code</h3>
                    </div>
                    <div class="panel-body" style="font-size: larger;">
                        <p><?php
                        echo $row['postal_code']
                        ?></p>
                    </div>
                  </div>
                </div>
                  <?php
                      }
                    }
                  ?>
           <!-- transaction -->
           
            <div class="col-md-9  admin-content" id="transaction">
            <table style="font-size: 150%" id="customers">
            <tr>
            <th>Reservation number</th>
            <th>Reservation Date</th>
            <th>Pickup Date</th>
            <th>Product Code</th>
            <th>Service Provider</th>
            <th>Status</th>
          </tr>
          <?php
          $user = ($_SESSION['username']);
          $queryTrans = "SELECT transaction.reservation_number, transaction.pickup_date, transaction.reservation_date, transaction.product_code, serviceprovider.owner_lastname, serviceprovider.owner_firstname, transaction.status FROM serviceprovider JOIN transaction on serviceprovider.serviceprov_id = transaction.serviceprov_id WHERE transaction.client_id = (SELECT client.client_id FROM client JOIN transaction ON client.client_id = transaction.client_id WHERE client.username = '".$user."' LIMIT 1);";
                        $result = mysqli_query($connect, $queryTrans);
                                if(mysqli_num_rows($result) > 0) {
                                    while($row = mysqli_fetch_array($result)) {
          ?>
          <tr>
            <td><?php echo $row['reservation_number']; ?></td>
            <td><?php echo $row['reservation_date']; ?></td>
            <td><?php echo $row['pickup_date']; ?></td>
            <td><?php echo $row['product_code']; ?></td>
            <td><?php echo $row['owner_firstname']." ".$row['owner_lastname']; ?></td>
            <td><?php echo $row['status']; ?></td>
          </tr>
          <?php
                                    }
                                }
          ?>
        </table>

        <div class="panel panel-info" style="margin: 2em; width: 96%">
            <form action="cancelReservation.php" method="post">
                        <div class="panel-heading">
                            <h3 class="panel-title"><label for="Reservation" class="control-label panel-title">Reservation Number</label></h3>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="reservation_number" id="reservation_number" required>
                                </div>
                            </div>

                        </div>
                    </div>

         <div class="pull-left">
           <input style="font-size: large" type="submit" class="form-control btn btn-primary" name="submit" id="submit" value="Cancel Reservation">
           </form>
        </div>

        


        </div>
                
            <!-- change password -->

                <div class="col-md-9  admin-content" id="change-password">
                <form action="changePassword.php" method="post">

                    <div class="panel panel-info" style="margin: 1em;">
                        <div class="panel-heading">
                            <h3 class="panel-title"><label for="old_password" class="control-label panel-title">Old Password</label></h3>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="col-sm-10">
                                    <input type="password" class="form-control" name="old_password" id="old_password" >
                                </div>
                            </div>

                        </div>
                    </div>

           
                    <div class="panel panel-info" style="margin: 1em;">
                        <div class="panel-heading">
                            <h3 class="panel-title"><label for="new_password" class="control-label panel-title">New Password</label></h3>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="col-sm-10">
                                    <input type="password" class="form-control" name="password" id="new_password" >
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="panel panel-info" style="margin: 1em;">
                        <div class="panel-heading">
                            <h3 class="panel-title"><label for="cpassword" class="control-label panel-title">Confirm password</label></h3>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="col-sm-10">
                                    <input type="password" class="form-control" name="password_confirmation" id="confirm_password" >
                                </div>
                            </div>
                        </div>
                    </div>

           
                    <div class="panel panel-info border" style="margin: 1em;">
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="pull-left">
                                    <input style="font-size: large;" type="submit" class="form-control btn btn-primary" name="submit" id="submit">
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
      </div>
      <?php
          if(isset($_POST['submit']))
              echo yes;
      ?>

<script type="text/javascript">


         $(document).ready(function()
      {
        var navItems = $('.admin-menu li > a');
        var navListItems = $('.admin-menu li');
        var allWells = $('.admin-content');
        var allWellsExceptFirst = $('.admin-content:not(:first)');
        allWellsExceptFirst.hide();
        navItems.click(function(e)
        {
            e.preventDefault();
            navListItems.removeClass('active');
            $(this).closest('li').addClass('active');
            allWells.hide();
            var target = $(this).attr('data-target-id');
            $('#' + target).show();
        });
        });
</script>
</body>

</html>