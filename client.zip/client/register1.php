<?php
	session_start();
	include('dbconfig/config.php');
	//phpinfo();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign Up Page</title>
<link rel="stylesheet" href="css/login.css">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/datepicker3.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">
</head>
<body style="background-image: url(regisbg.jpg);">
	<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
		<div class="login-panel panel panel-success text-center">
			<div class="panel-heading">Sign Up Form</div>
				<form action="register.php" method="post">
				<div class="panel-body">
					<fieldset>
						 <div class="form-group text-center">
							<input class="form-control" type="text" placeholder="Enter Username (first letter capital)" name="username" required>
						</div>
						<div class="form-group text-center">
							<input class="form-control" type="password" placeholder="Enter Password (minimum if 8 characters)" name="password" required minlength="8">
						</div>
						<div class="form-group text-center">
							<input class="form-control" type="password" placeholder="Re-Enter Password" name="cpassword" required minlength="8">
						</div>
						<div class="form-group text-center">
							<input class="form-control" type="text" placeholder="Email" name="email" required>
						</div>
						<div class="form-group text-center">
							<input class="form-control" type="text" placeholder="Firstname" name="firstname" required>
						</div>
						<div class="form-group text-center">
							<input class="form-control" type="text" placeholder="Lastname" name="lastname" required>
						</div>
						<div class="form-group text-center">
							<input class="form-control" type="number" placeholder="Phone Number" name="phone_number" required>
						</div>
						<div class="form-group text-center">
							<input class="form-control" type="text" placeholder="Address" name="address_line" required>
						</div>
						<div class="form-group text-center">
							<input class="form-control" type="text" placeholder="City" name="city" required>
						</div>
						<div class="form-group text-center">
							<input class="form-control" type="text" placeholder="Province" name="province" required>
						</div>
						<div class="form-group text-center">
							<input class="form-control" type="number" placeholder="Postal Code" name="postal_code" required>
						</div>
				

				<button name="register" class="btn btn-success btn-lg" type="submit">Sign Up</button>
				
				<a href="index.php"><button type="button" class="btn btn-primary btn-lg">Back to Login</button></a>

				
			</div>
		</form>
		
		<?php
			if(isset($_POST['register']))
			{
				@$username=$_POST['username'];
				@$password=$_POST['password'];
				@$cpassword=$_POST['cpassword'];
				@$email=$_POST['email'];
				@$firstname=$_POST['firstname'];
				@$lastname=$_POST['lastname'];
				@$phone_number=$_POST['phone_number'];
				@$address_line=$_POST['address_line'];
				@$city=$_POST['city'];
				@$province=$_POST['province'];
				@$postal_code=$_POST['postal_code'];

				if($password==$cpassword)
				{
					$query = "select * from client where username ='$username'";
					//echo $query;
				$query_run = mysqli_query($connect, $query);
				//echo mysql_num_rows($query_run);
				if($query_run)
					{
						if(mysqli_num_rows($query_run)>0)
						{
							echo '<script type="text/javascript">alert("This Username Already exists.. Please try another username!")</script>';
						}
						else
						{
							$stmt = $connect->prepare("INSERT INTO client (username, password, email, firstname, lastname, phone_number, address_line, city, province, postal_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
							$stmt->bind_param('ssssssssss', $username, $password, $email, $firstname, $lastname, $phone_number, $address_line, $city, $province, $postal_code);
							$username = $username;
							$password = $password;
							$email = $email;
							$firstname = $firstname;
							$lastname = $lastname;
							$phone_number = $phone_number;
							$address_line = $address_line;
							$city = $city;
							$province = $province;
							$postal_code = $postal_code;
							$stmt->execute();
							if($query_run)
							{
								echo '<script type="text/javascript">alert("User Registered.. Welcome")</script>';
								$_SESSION['username'] = $username;
								$_SESSION['password'] = $password;
								$_SESSION['email'] = $email;
								$_SESSION['firstname'] = $firstname;
								$_SESSION['lastname'] = $lastname;
								$_SESSION['phone_number'] = $phone_number;
								$_SESSION['address_line'] = $address_line;
								$_SESSION['city'] = $city;
								$_SESSION['province'] = $province;
								$_SESSION['postal_code'] = $postal_code;
								header( "Location: index.php");
							}
							else
							{
								echo '<p class="bg-danger msg-block">Registration Unsuccessful due to server error. Please try later</p>';
							}
						}
					}
					else
					{
						echo '<script type="text/javascript">alert("DB error")</script>';
					}
				}
				else
				{
					echo '<script type="text/javascript">alert("Password and Confirm Password do not match")</script>';
				}
				
			}
			else
			{
			}
		?>
	</div>
</body>
</html>