<?php 
session_start();
  	include('dbconfig/config.php');

if(isset($_POST["add_to_cart"]))
{
	if(isset($_SESSION["shopping_cart"]))
	{
		$item_array_product_code = array_column($_SESSION["shopping_cart"], "item_product_code");
		if(!in_array($_GET["product_code"], $item_array_product_code))
		{
			$count = count($_SESSION["shopping_cart"]);
			$item_array = array(
				'item_product_code'			=>	$_GET["product_code"],
				'item_name'			=>	$_POST["hidden_name"],
				'item_rental_price'		=>	$_POST["hidden_rental_price"],
				'item_quantity'		=>	$_POST["quantity"]
			);
			$_SESSION["shopping_cart"][$count] = $item_array;
		}
		else
		{
			echo '<script>alert("Item Already Added")</script>';
		}
	}
	else
	{
		$item_array = array(
			'item_product_code'			=>	$_GET["product_code"],
			'item_name'			=>	$_POST["hidden_name"],
			'item_rental_price'		=>	$_POST["hidden_rental_price"],
			'item_quantity'		=>	$_POST["quantity"]
		);
		$_SESSION["shopping_cart"][0] = $item_array;
	}
}

if(isset($_GET["action"]))
{
	if($_GET["action"] == "delete")
	{
		foreach($_SESSION["shopping_cart"] as $keys => $values)
		{
			if($values["item_product_code"] == $_GET["product_code"])
			{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>alert("Item Removed")</script>';
				echo '<script>window.location="costumes.php"</script>';
			}
		}
	}
}

?>
<!DOCTYPE html>
<html lang="en">

  <head>
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Costume And Attires</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/heroic-features.css" rel="stylesheet">

  </head>

  <body data-spy="scroll" data-target="#myScrollspy" data-offset="20" >
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top text-white" id="myScrollspy" style="font-size: large; background-color: black;">
      <div class="container">
        <a href="index.php"><img src="home design/img/logo.png" class="navbar-brand js-scroll-trigger" id="logo" style="width:90px;height:60px;"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
		<form action="search.php" method="POST" class="md-form active-cyan-2 mb-3" style="padding-top: 10px;">
    	
				<input class="form-control" name="search" style="font-size: large;" type="text" placeholder="Search" aria-label="Search">
			</form>
			<div>
			
			<?php
			
			//$topic=$_REQUEST["topic"];
			$sql = $query = "SELECT product.name, product.rental_price, concat(serviceprovider.owner_firstname, ' ', serviceprovider.owner_lastname), product_category.category_name from product JOIN product_category on product.category_id = product_category.category_id JOIN serviceprovider on product.product_providerid = serviceprovider.serviceprov_id WHERE product.name LIKE '%casual%'";
			$result = mysqli_query($connect,$sql);
			$queryResults = mysqli_num_rows($result);	
			?>

			</div>
          <ul class="navbar-nav ml-auto">
          	
            <li class="nav-item">
              <a class="nav-link" href="costumes.php">Rentals</a>
            </li>
            <li class="nav-item">
              <?php
              if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                  echo "<a class='nav-link' href='profile.php'>". $_SESSION['username'] ."</a>";
              } else {
                  echo "<a class='nav-link' href='index.php'>Login</a>";
              }
               ?>
            </li>
             
            <li class="nav-item">
              <?php
              if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                  echo "<a class='nav-link' href='logout.php'>Logout</a>";
              } else {
                  echo "";
              }
               ?>
            </li>
          </ul>
        </div>
      </div>
    </nav>
<br /><br />
	  <h3 align="center">
	      <a href="costumes.php" class="btn btn-info" role="button">Costumes</a>
	      <a href="attires.php" class="btn btn-info" role="button">Attires</a></h3>
      <h3 align="center">
	      <a href="halloween.php" class="btn btn-info" role="button">Halloween</a>
	      <a href="christmas.php" class="btn btn-info" role="button">Christmas</a>
	      <a href="cosplay.php" class="btn btn-info" role="button">Cosplay</a></h3>
      <br/>
			<?php
				$query = "SELECT * FROM product JOIN product_category using(category_id) WHERE category_id = 7 ORDER BY product_code ASC";
				$result = mysqli_query($connect, $query);
				if(mysqli_num_rows($result) > 0)
				{
					while($row = mysqli_fetch_array($result))
					{
				?>
			<div class="col-md-4">
				<form method="post" action="costumes.php?action=add&product_code=<?php echo $row["product_code"]; ?>">
					<div class="panel">
					<div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">
						<img src="images/<?php echo $row["product_image"]; ?>" class="img-responsive" /><br />

						<h4 class="text-info"><?php echo $row["name"]; ?></h4>

						<h4 class="text-danger">$ <?php echo $row["rental_price"]; ?></h4>

						<input type="text" name="quantity" value="1" class="form-control" />

						<input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />

						<input type="hidden" name="hidden_rental_price" value="<?php echo $row["rental_price"]; ?>" />

						<input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Add to Cart" />

					</div>
				</div>
				</form>
			</div>
			<?php
					}
				}
			?>
			<div style="clear:both"></div>
			<br />
			<h3>Order Details</h3>
			<div class="table-responsive">
				<table class="table table-bordered">
					<tr>
						<th width="40%">Item Name</th>
						<th width="10%">Quantity</th>
						<th width="20%">Price</th>
						<th width="15%">Total</th>
						<th width="5%">Action</th>
					</tr>
					<?php
					if(!empty($_SESSION["shopping_cart"]))
					{
						$total = 0;
						foreach($_SESSION["shopping_cart"] as $keys => $values)
						{
					?>
					<tr>
						<td><?php echo $values["item_name"]; ?></td>
						<td><?php echo $values["item_quantity"]; ?></td>
						<td>$ <?php echo $values["item_rental_price"]; ?></td>
						<td>$ <?php echo number_format($values["item_quantity"] * $values["item_rental_price"], 2);?></td>
						<td><a href="costumes.php?action=delete&product_code=<?php echo $values["item_product_code"]; ?>"><span class="text-danger">Remove</span></a></td>
					</tr>
					<?php
							$total = $total + ($values["item_quantity"] * $values["item_rental_price"]);
						}
					?>
					<tr>
						<td colspan="3" align="right">Total</td>
						<td align="right">$ <?php echo number_format($total, 2); ?></td>
						<td></td>
					</tr>
					<?php
					}
					?>
						
				</table>
			</div>
		</div>
	</div>
	<?php include 'inc/footer.php'; ?>